package com.example.backend_HistorialClinico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class backend_HistorialClinicoApplicationTests {

	@Test
	void contextLoads() {
	}

}
