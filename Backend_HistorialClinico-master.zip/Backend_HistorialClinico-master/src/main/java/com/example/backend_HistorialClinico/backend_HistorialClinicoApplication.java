package com.example.backend_HistorialClinico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class backend_HistorialClinicoApplication {

	public static void main(String[] args) {
		SpringApplication.run(backend_HistorialClinicoApplication.class, args);
	}

}
