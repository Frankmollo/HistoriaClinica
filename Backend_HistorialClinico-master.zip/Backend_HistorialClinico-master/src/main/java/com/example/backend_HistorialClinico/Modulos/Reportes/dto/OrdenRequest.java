package com.example.backend_HistorialClinico.Modulos.Reportes.dto;

public class OrdenRequest {
    private String columna;
    private String direccion;
    
    public String getColumna() {
        return columna;
    }
    public void setColumna(String columna) {
        this.columna = columna;
    }
    public String getDireccion() {
        return direccion;
    }
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    // Getters y Setters
    // ...
}